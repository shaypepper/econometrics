setwd("/Users/shaypepper/Documents/school/econometrics/")
load("data/cps_mar2013/cps_mar2013.RData")

attach(dat_CPSMar2013)


